HW2_109064509_1.mlx is the main program

count_samples.m plot_pdf.m plot_cdf.m  are functions that were built by myself and used

HW2_109064509.pdf is the report