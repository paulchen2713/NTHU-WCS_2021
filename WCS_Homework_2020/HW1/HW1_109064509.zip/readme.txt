HW1_109064509_1.mlx is the main program

TOT.m ln_factorial.m exp_power_series.m secant_method.m are functions that were built by myself and used

HW1_109064509.pdf is the report